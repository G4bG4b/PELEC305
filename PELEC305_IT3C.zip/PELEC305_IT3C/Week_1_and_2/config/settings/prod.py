from .base import *

DEBUG = False

ALLOWED_HOSTS = ['dizme.site']
DATABASES = {
    'default':{
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': "dizapp",
        'USER': 'dizme',
        'PASSWORD': 'password',
        'HOST': 'localhost',
        'PORT': '5432'
    }
}