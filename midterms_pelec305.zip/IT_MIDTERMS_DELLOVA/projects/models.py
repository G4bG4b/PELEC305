from django.db import models
from django.core.exceptions import ValidationError

# Create your models here.
class StudentProfile(models.Model):
    name = models.CharField(max_length=100, )
    course = models.CharField(max_length=100)
    year_level = models.IntegerField()

    def __str__(self):
        return self.name

class Project(models.Model):
    student = models.ForeignKey(StudentProfile, on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    description = models.TextField()
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def clean_title(self):
        if len(self.title) < 10:
            raise ValidationError('Title must be at least 10 characters long.')
        
    def clean_description(self):
        if len(self.description) < 20:
            raise ValidationError('Description must be at least 20 characters long.')
        
    def __str__(self):
        return self.title