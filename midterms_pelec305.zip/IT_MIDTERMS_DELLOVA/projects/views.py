from django.shortcuts import render, redirect
from .models import StudentProfile, Project
from django.contrib.auth.decorators import login_required

# Create your views here.
def Register(request):
    if request.method == 'POST':
        StudentProfile.objects.create(
            name=request.POST['name'],
            course=request.POST['course'],
            year_level=request.POST['year_level'],
            password=request.POST['password'],
        )
        return redirect('login')
    return render(request, 'register.html')

@login_required
def dashboard(request):
    projects = Project.objects.filter(student=request.user)
    return render(request, 'dashboard.html', {'projects': projects})
