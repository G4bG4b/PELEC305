from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    path('login/', auth_views.LoginView.as_view(template_name='login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('register/', views.Register, name='register'),
    path('dashboard/', views.dashboard, name='dashboard'),

    path('admin-page/', views.admin_page, name='admin_page'),
    path('seller-page/', views.seller_page, name='seller_page'),
    path('costomer-page/', views.costomer_page, name='costomer_page'),    
]