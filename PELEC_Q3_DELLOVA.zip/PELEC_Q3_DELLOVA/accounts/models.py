from django.db import models
from django.contrib.auth.models import AbstractUser 

# Create your models here.
ROLE_CHOISES = (
    ('admin', 'Admin'),
    ('seller', 'Seller'),
    ('costomer', 'Costomer'),
)

class User(AbstractUser):
    role = models.CharField(choices=ROLE_CHOISES, default='costomer')
    def __str__(self):
        return f'{self.username} ({self.role})' 