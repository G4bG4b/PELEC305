from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .models import User

# Create your views here.
def Register(request):
    if request.method == 'POST':
        User.objects.create_user(
            username=request.POST['username'],
            password=request.POST['password'],
            role=request.POST['role']
        )
        return redirect('login')
    return render(request, 'register.html')

@login_required
def dashboard(request):
    user = request.user

    if user.role == 'admin':
        return redirect('admin_page')
    elif user.role == 'seller':
        return redirect('seller_page')
    else:
        return redirect('costomer_page')
    
@login_required
def admin_page(request):
    if request.user.role != 'admin':
        return redirect('dashboard')
    return render(request, 'admin.html')

@login_required
def seller_page(request):
    if request.user.role != 'seller':
        return redirect('dashboard')
    return render(request, 'seller.html')

@login_required
def costomer_page(request):
    if request.user.role != 'costomer':
        return redirect('dashboard')
    return render(request, 'costomer.html')

